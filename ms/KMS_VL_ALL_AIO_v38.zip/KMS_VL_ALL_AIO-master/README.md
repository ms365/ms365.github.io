# KMS_VL_ALL_AIO
Smart Activation Script
