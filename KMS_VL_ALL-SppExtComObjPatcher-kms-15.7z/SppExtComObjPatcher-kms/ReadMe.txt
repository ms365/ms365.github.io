================================================================
# To install this solution for auto renewal activation, run these scripts Respectively:
Clear-KMS-Cache.cmd         (Optional)
SppExtComObjPatcher.cmd     // to install/uninstall the Patcher Hook
Activate-Local.cmd          // to activate local machine. (you must run it at least once)
Check-Activation-Status.cmd (Optional)

================================================================
# To just activate without installing and without renewal, run this script only:
KMS_VL_ALL.cmd

you will need to run it again before the activation period expire (6 months default)

================================================================
# Supported Volume Products:
Windows 7/8/8.1/10
Windows Server 2008R2/2012/2012R2/2016
Office 2010/2013/2016

================================================================
# Bonus:

- To preactivate the system during installation, copy $oem$ to "sources" folder in the installation media (iso/usb)

- if you already use another setupcomplete.cmd, rename this one to KMS_VL_ALL.cmd or similar name
then add a command to run it in your setupcomplete.cmd, example:
call KMS_VL_ALL.cmd

- use SppExtComObjPatcher.cmd if you want to uninstall the project afterwards.

- note: setupcomplete.cmd is disabled if the default installed key for the edition is OEM Channel

================================================================
- Credits 
qad            - SppExtComObjPatcher
MasterDisaster - initial script / WMI methods
qewpal         - KMS_VL_ALL author
Nucleus        - Special assistance
abbodi1406     - Me :)
